package com.doyourthng.task;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.MenuCompat;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar menuToolbar;
    private FrameLayout frameLayout;
    private Button projectInfo, similarApps, features, random,startProject, startProject2;
    private ImageView info;
    private RelativeLayout infoClicked, bottomToolbar, topLayout;
    private boolean oninfo, onSimilarApps, onProjectInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        instantiateViews();

        projectInfo.setOnClickListener(this);
        similarApps.setOnClickListener(this);
        features.setOnClickListener(this);
        random.setOnClickListener(this);
        startProject.setOnClickListener(this);
        startProject2.setOnClickListener(this);
        info.setOnClickListener(this);

        menuToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(item.getItemId() == R.id.download){
                    Toast.makeText(getApplicationContext(),"Download Clicked",Toast.LENGTH_LONG).show();
                    return true;
                }else if(item.getItemId()==R.id.invite){
                    Toast.makeText(getApplicationContext(),"Invite Clicked",Toast.LENGTH_LONG).show();
                    return true;
                }else if(item.getItemId()==R.id.transfer){
                    Toast.makeText(getApplicationContext(),"Transfer Clicked",Toast.LENGTH_LONG).show();
                    return true;
                }else if(item.getItemId()==R.id.share){
                    Toast.makeText(getApplicationContext(),"Share Clicked",Toast.LENGTH_LONG).show();
                    return true;
                }
                return false;
            }
        });

        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new ProjectInfoFragment()).commit();



    }

    public void instantiateViews(){
        menuToolbar = findViewById(R.id.menu_toolbar);
        menuToolbar.inflateMenu(R.menu.options_menu);
        frameLayout = findViewById(R.id.frameLayout);
        projectInfo = findViewById(R.id.projectInfo);
        similarApps = findViewById(R.id.similarApps);
        features = findViewById(R.id.features);
        random = findViewById(R.id.random);
        startProject = findViewById(R.id.startProject);
        startProject2 = findViewById(R.id.startProject2);
        info = findViewById(R.id.info);
        infoClicked = findViewById(R.id.info_clicked_layout);
        bottomToolbar = findViewById(R.id.bottomLayout);
        topLayout = findViewById(R.id.topLayout);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuCompat.setGroupDividerEnabled(menu, true);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.projectInfo:
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new ProjectInfoFragment()).addToBackStack(null).commit();
                makeProjectInfoActive();
                break;
            case R.id.similarApps:
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,new SimilarAppsFragment()).addToBackStack(null).commit();
                makeSimilarAppsActive();
                break;
            case R.id.features:
                Toast.makeText(getApplicationContext(),"Features Clicked",Toast.LENGTH_LONG).show();
                break;
            case R.id.random:
                Toast.makeText(getApplicationContext(),"Random Button Clicked",Toast.LENGTH_LONG).show();
                break;
            case R.id.startProject:
                Toast.makeText(getApplicationContext(),"Start Project Clicked",Toast.LENGTH_LONG).show();
                break;
            case R.id.startProject2:
                Toast.makeText(getApplicationContext(),"Start Project Clicked",Toast.LENGTH_LONG).show();
                break;
            case R.id.info:
                bottomToolbar.setVisibility(View.GONE);
                infoClicked.setVisibility(View.VISIBLE);
                topLayout.setAlpha(0.4f);
                oninfo=true;
                break;

        }

    }

    @Override
    public void onBackPressed(){
        if(oninfo){
            oninfo=false;
            bottomToolbar.setVisibility(View.VISIBLE);
            infoClicked.setVisibility(View.GONE);
            topLayout.setAlpha(1f);
            return;
        }else if(onSimilarApps && getSupportFragmentManager().getBackStackEntryCount()>0){
            getSupportFragmentManager().popBackStack();
            makeProjectInfoActive();
            return;

        }else if(onProjectInfo && getSupportFragmentManager().getBackStackEntryCount()>0){
            getSupportFragmentManager().popBackStack();
            makeSimilarAppsActive();
            return;
        }
        super.onBackPressed();
    }

    public void makeProjectInfoActive(){
        onProjectInfo=true; onSimilarApps = false;
        projectInfo.setBackgroundResource(R.drawable.button_background_active);
        projectInfo.setTextColor(getResources().getColor(R.color.white));
        similarApps.setBackgroundResource(R.drawable.button_background_inactive);
        similarApps.setTextColor(getResources().getColor(R.color.black));
    }

    public void makeSimilarAppsActive(){
        onSimilarApps = true; onProjectInfo = false;
        similarApps.setBackgroundResource(R.drawable.button_background_active);
        similarApps.setTextColor(getResources().getColor(R.color.white));
        projectInfo.setBackgroundResource(R.drawable.button_background_inactive);
        projectInfo.setTextColor(getResources().getColor(R.color.black));
    }
}
